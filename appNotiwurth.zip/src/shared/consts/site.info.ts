export const SiteInfo = {
    title : 'My Site',
    description : 'This is my site',
}